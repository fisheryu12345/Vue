<template>
<div>
  测试框架外显示
</div>
</template>

<script setup lang="ts" name="demo">

</script>

<style scoped>

</style>
